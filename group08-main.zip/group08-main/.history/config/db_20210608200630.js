module.exports =
{
    "URI"
}