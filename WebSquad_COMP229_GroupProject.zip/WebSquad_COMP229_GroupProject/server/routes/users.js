/*File Name: GokulrajVenugopal_COMP229_Assignment2
Student Name: Gokulraj Venugopal
Student ID: 301202722
Date: 21-Feb-2022 
*/

var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('Placeholder');
});

module.exports = router;
