module.exports =
{
    "URL": "mongodb://localhost/business"
    
}