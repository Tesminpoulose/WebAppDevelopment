module.exports =
{
    "URI":"mongodb"
}