module.exports =
{
    "UR": "mongodb://localhost/business"
    
}