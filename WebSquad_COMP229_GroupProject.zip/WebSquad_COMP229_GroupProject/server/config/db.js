/*File Name: GokulrajVenugopal_COMP229_Assignment2
Student Name: Gokulraj Venugopal
Student ID: 301202722
Date: 21-Feb-2022 
*/

module.exports = 
{
    //"URI": "mongodb://0.0.0.0:27017/WebAppDev"
    "URI": "mongodb+srv://Gokulraj:EBdMavrqiB8yYa9M@mongodbserver.is4xt.mongodb.net/WebAppDev?retryWrites=true&w=majority",
    "Secret": 'SomeSecret'
}