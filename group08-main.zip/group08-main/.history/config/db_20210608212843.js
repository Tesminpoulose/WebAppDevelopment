module.exports =
{
    "URI":"mongodb://localhost/business
}