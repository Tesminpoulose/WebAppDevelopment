module.exports =
{
    "URI": "mongodb://localhost/business_contacts"
    
}