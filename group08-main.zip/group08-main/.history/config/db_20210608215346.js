module.exports =
{
    "URI": "mongodb://localhost:27020/mydb"
    
}