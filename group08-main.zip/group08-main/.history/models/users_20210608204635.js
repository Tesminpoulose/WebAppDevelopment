let mongoose = required('mongoose');

//create a model classs

let usersModel = 
